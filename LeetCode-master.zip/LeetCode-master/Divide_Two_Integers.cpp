/*
Author:     Weixian Zhou, ideazwx@gmail.com
Date:       June 28, 2012
Problem:    Divide two integers
Difficulty: boring
Source:     http://www.leetcode.com/onlinejudge
Notes:
Divide two integers without using multiplication, division and mod operator.

Solution:
This is boring.
*/
#include <vector>
#include <set>
#include <climits>
#include <algorithm>
#include <iostream>
#include <sstream>
#include <cmath>
#include <cstring>
using namespace std;

class Solution {
public:
    int divide(int dividend, int divisor) {
        return dividend / divisor;
    }
};


